<?php
$steamstatusI = $playerstats->response->players[0]->personastate;
if ($steamstatusI == "0") {
    $steamstatus = "Offline";
  } else {
    $steamstatus = "Online";
  }
$steamname = $playerstats->response->players[0]->personaname;
$avatarurl = $playerstats->response->players[0]->avatarfull;
$playerlevel = $getplayerlevel->response->player_level;
$recentlyname = $recentlyplayed->response->games[0]->name;
// Frage die insgesamt gespielte Zeit des zuletzt gespielten Spiels ab. Da die zeit in Minuten ausgegeben wird Wandel ich sie in 'hh:mm' um.
$recentlytime = $recentlyplayed->response->games[0]->playtime_forever;
$t = $recentlytime;
$h = floor($t/60) ? floor($t/60) .':': '';
$m = $t%60 ? $t%60 .'h' : '';
$recentlytime = $h && $m ? $h.''.$m : $h.$m;


$appid = $recentlyplayed->response->games[0]->appid;
$battlemetricstimeraw = $battlemetrics->data->attributes->timePlayed;

$bmtimec = gmdate("H:i:s", $battlemetricstimeraw);

include('ownedgamesapi.php');
?>