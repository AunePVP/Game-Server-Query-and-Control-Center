<?php 

$ownedgameslistI = $ownedgames->response->games[0]->name;
$ownedgameslistII = $ownedgames->response->games[1]->name;
$ownedgameslistIII = $ownedgames->response->games[2]->name;
$ownedgameslistIV = $ownedgames->response->games[3]->name;
$ownedgameslistV = $ownedgames->response->games[4]->name;
$ownedgameslistVI = $ownedgames->response->games[5]->name;
$ownedgameslistVII = $ownedgames->response->games[6]->name;
$ownedgameslistVIII = $ownedgames->response->games[7]->name;
$ownedgameslistIX = $ownedgames->response->games[8]->name;
$ownedgameslistX = $ownedgames->response->games[9]->name;
$ownedgameslistXI = $ownedgames->response->games[10]->name;
$ownedgameslistXII = $ownedgames->response->games[11]->name;
$ownedgameslistXIII = $ownedgames->response->games[12]->name;
$ownedgameslistXIV = $ownedgames->response->games[13]->name;
$ownedgameslistXV = $ownedgames->response->games[14]->name;
$ownedgameslistXVI = $ownedgames->response->games[15]->name;
$ownedgameslistXVII = $ownedgames->response->games[16]->name;
$ownedgameslistXVIII = $ownedgames->response->games[17]->name;
$ownedgameslistXIX = $ownedgames->response->games[18]->name;
$ownedgameslistXX = $ownedgames->response->games[19]->name;
?>