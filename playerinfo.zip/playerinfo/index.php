<?php

$steamid = $_GET['steamid'];
$playerid = "1021555380";
$serverid = "13923165";
$key = "70EBA93B99230FB194CD99CC10160D72";
$steamapi = "https://api.steampowered.com/";
// json Links erstellen
$linkplayerstats = $steamapi . "ISteamUser/GetPlayerSummaries/v2/?key=" . $key . "&steamids=" . $steamid;
$linkplayerlevel = $steamapi . "IPlayerService/GetSteamLevel/v1/?key=" . $key . "&steamid=" . $steamid;
$linkrecentlyplayed = $steamapi . "IPlayerService/GetRecentlyPlayedGames/v1/?key=" . $key . "&steamid=" . $steamid;
$linkownedgames = $steamapi . "IPlayerService/GetOwnedGames/v1/?key=" . $key . "&steamid=" . $steamid . "&include_appinfo=true";
$linkbattlemetrics = "https://api.battlemetrics.com/players/" . $playerid . "/servers/" . $serverid;
//Json Decode Abfragen
$playerstats = json_decode(file_get_contents($linkplayerstats));
$getplayerlevel = json_decode(file_get_contents($linkplayerlevel));
$recentlyplayed = json_decode(file_get_contents($linkrecentlyplayed));
$ownedgames = json_decode(file_get_contents($linkownedgames));
$battlemetrics = json_decode(file_get_contents($linkbattlemetrics));
require('getapi.php');

?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <link rel="icon" href="favico.ico" type="image/ico" />
          <title><?php echo $steamname?></title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
    <div id="nav">
    <table id="nav-table">
                <tbody>
                    <td class="status_cell">
                        <div id="steamstatus">
                            <?php echo $steamstatus; ?>
                        </div>
                    </td>
                    <td class="mitte_cell"></td>
                    <td class="name_cell">
                    <div class="playerAvatar profile_header_size offline" data-miniprofile="1183530147">
										<div class="playerAvatarAutoSizeInner">
													<div class="profile_avatar_frame">
								<img src="https://cdn.cloudflare.steamstatic.com/steamcommunity/public/images/items/601220/4957cc68eec4c2d9ee1df6de65f073951d1e94ee.png">
							</div>
												<img src="<?php echo $avatarurl?>">
					</div></div>
                <div id="name-level">
                    <div id="steam_name"><?php echo $steamname ?></div>
                    <div id="level">Level <?php echo $playerlevel?></div>
                </div>
                    </td>
                </tr>
              </tbody></table>
    </div>
    <div class="main">
        <div id="I">
            <div class="zuletzt">
                <div>&nbsp;Zuletzt Gespielt:</div>
                <div id="geht">
                <div id="lastgame">
                    <div class="w40">
                        <img id="ttki"src="https://cdn.cloudflare.steamstatic.com/steam/apps/<?php echo $appid?>/capsule_231x87.jpg" alt="">
                    </div>
                    <div class="w37">
                        <div style="font-size: 20px;padding-top:29.5px;}"><?php echo $recentlyname?></div>
                    </div>
                    <div class="w23">Insgesamt <?php echo $recentlytime ?></div>
                </div>
                </div>
            </div>
        </div>
        <div id="II">
            <div id="besitz">
                <div>Spiele im Besitz</div>
                <div id="liste">
                    <div><?php echo $ownedgameslistI ?></div>
                    <div><?php echo $ownedgameslistII ?></div>
                    <div><?php echo $ownedgameslistIII ?></div>
                    <div><?php echo $ownedgameslistIV ?></div>
                    <div><?php echo $ownedgameslistV ?></div>
                    <div><?php echo $ownedgameslistVI ?></div>
                    <div><?php echo $ownedgameslistVII ?></div>
                    <div><?php echo $ownedgameslistVIII ?></div>
                    <div><?php echo $ownedgameslistIX ?></div>
                    <div><?php echo $ownedgameslistX ?></div>
                    <div><?php echo $ownedgameslistXI ?></div>
                    <div><?php echo $ownedgameslistXII ?></div>
                    <div><?php echo $ownedgameslistXII ?></div>
                    <div><?php echo $ownedgameslistXIV ?></div>
                    <div><?php echo $ownedgameslistXV ?></div>
                    <div><?php echo $ownedgameslistXVI ?></div>
                    <div><?php echo $ownedgameslistXVII ?></div>
                    <div><?php echo $ownedgameslistXVIII ?></div>
                    <div><?php echo $ownedgameslistXIX ?></div>
                    <div><?php echo $ownedgameslistXX ?></div>
                    
                </div>
            </div>
        </div>
        <div id="III">
            <div id="server">
                <div>&nbsp;Server</div>
                <div id="liste">
                    <div>Gespielte Zeit: <?php echo $bmtimec;?>h</div>
                    <div>Zuletzt gesehen: 21:17Uhr</div>
                    <div>Status: Offline</div>
                </div>
            </div>
        </div>

    </div>
    </body>
</html>